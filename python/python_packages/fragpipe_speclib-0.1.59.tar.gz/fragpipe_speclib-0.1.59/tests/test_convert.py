import re
import unittest

import pandas as pd

from easypqp import convert
from easypqp.convert import get_scan


class TestConvert(unittest.TestCase):

    def test_get_scan(self):
        self.assertEqual(11, get_scan("controllerType=0 controllerNumber=1 scan=2 demux=0", 11))
        self.assertEqual(11, get_scan("sample=2 period=3 cycle=4 experiment=5", 11))
        self.assertEqual(11, get_scan("frame=2 scan=3", 11))

        self.assertEqual(11, get_scan("controllerType=0 controllerNumber=1 scan=11", 22))
        self.assertEqual(11, get_scan("function=0 process=1 scan=11", 22))
        self.assertEqual(11, get_scan("jobRun=0 spotLabel=asw spectrum=11", 22))
        self.assertEqual(11, get_scan("11", 22))
        self.assertEqual(11, get_scan("scan=11", 22))
        self.assertEqual(11, get_scan("spectrum=11", 22))
        self.assertEqual(11, get_scan("scanId=11", 22))
        self.assertEqual(11, get_scan("index=11", 22))
        self.assertEqual(11, get_scan("frame=11", 22))


class _UnannotatedUnimod:
    """Stub Unimod whose lookups always miss, forcing the unannotated `[mass]` branch."""

    def get_id(self, *args, **kwargs):
        return -1


class TestTerminalModNotation(unittest.TestCase):
    """match_modifications must write unannotated terminal mods as a signed delta
    ('.[+mass]' / '.[-mass]'), so OpenMS treats the mass as a delta and not as the
    absolute mass of the terminal group (which would drop the N-terminal H / C-terminal OH)."""

    def _modified_peptide(self, row):
        inst = object.__new__(convert.psmtsv)
        inst.psms = pd.DataFrame([row])
        inst.enable_massdiff = False
        inst.exclude_range = [-1.5, 3.5]
        inst.ignore_unannotated = False
        inst.enable_unannotated = True
        inst.match_unimod(_UnannotatedUnimod())
        return inst.psms['modified_peptide'].iloc[0]

    def test_nterm_cterm_and_residue_get_signed_delta(self):
        row = {
            'peptide_sequence': 'EVGEHLVSIK',
            'modifications': 'M|5$333.333333',
            'nonlabile_modifications': 'M',
            'nterm_modification': 111.111111,
            'cterm_modification': 222.222222,
            'massdiff': '0.0',
        }
        self.assertEqual(
            self._modified_peptide(row),
            '.[+111.111111]EVGEH[+333.333333]LVSIK.[+222.222222]',
        )

    def test_negative_terminal_mod_keeps_minus_sign(self):
        row = {
            'peptide_sequence': 'EVGEHLVSIK',
            'modifications': 'M',
            'nonlabile_modifications': 'M',
            'nterm_modification': -17.026549,
            'cterm_modification': '',
            'massdiff': '0.0',
        }
        self.assertEqual(self._modified_peptide(row), '.[-17.026549]EVGEHLVSIK')


class TestPepxmlAbsoluteMassParsing(unittest.TestCase):
    """pepXML stores ABSOLUTE terminus masses; match_modifications must subtract the bare
    terminus (monoisotopic H at the N-term, monoisotopic OH at the C-term) to recover the delta."""

    def _terminal_deltas(self, nterm_abs, cterm_abs):
        row = {
            'peptide_sequence': 'EVGEHLVSIK',
            'modifications': 'M',
            'nterm_modification': nterm_abs,
            'cterm_modification': cterm_abs,
            'massdiff': '0.0',
        }
        inst = object.__new__(convert.pepxml)
        inst.psms = pd.DataFrame([row])
        inst.enable_massdiff = False
        inst.exclude_range = [-1.5, 3.5]
        inst.enable_unannotated = True
        inst.match_unimod(_UnannotatedUnimod())
        mp = inst.psms['modified_peptide'].iloc[0]
        return [float(m) for m in re.findall(r'\[([+-][0-9.]+)\]', mp)]

    def test_absolute_terminus_masses_become_correct_deltas(self):
        # absolute terminus mass = bare terminus (mono H / mono OH) + intended delta
        H, OH = 1.00783, 17.00274
        deltas = self._terminal_deltas(H + 42.010565, OH + 14.015650)
        self.assertEqual(len(deltas), 2)                          # only N-term and C-term brackets
        self.assertAlmostEqual(deltas[0], 42.010565, places=4)    # N-term: bare H subtracted
        self.assertAlmostEqual(deltas[-1], 14.015650, places=4)   # C-term: bare OH subtracted (not H2O)


if __name__ == '__main__':
    unittest.main()



