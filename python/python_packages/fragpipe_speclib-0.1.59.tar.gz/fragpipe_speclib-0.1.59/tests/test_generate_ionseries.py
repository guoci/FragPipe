import unittest

from easypqp.convert import generate_ionseries

# Monoisotopic residue masses (Da) used to compute the expected fragment m/z
# independently of OpenMS, so the assertions document the chemistry.
_RESIDUE = {
    'A': 71.03711, 'R': 156.10111, 'N': 114.04293, 'D': 115.02694,
    'C': 103.00919, 'E': 129.04259, 'Q': 128.05858, 'G': 57.02146,
    'H': 137.05891, 'I': 113.08406, 'L': 113.08406, 'K': 128.09496,
    'M': 131.04049, 'F': 147.06841, 'P': 97.05276, 'S': 87.03203,
    'T': 101.04768, 'W': 186.07931, 'Y': 163.06333, 'V': 99.06841,
}
_PROTON = 1.0072765
_H2O = 18.0105646


def _b_ion(prefix, mod_sum, charge=1):
    """Theoretical N-terminal (b) ion m/z. mod_sum = N-term mod + residue mods on the prefix."""
    neutral = sum(_RESIDUE[a] for a in prefix) + mod_sum
    return (neutral + charge * _PROTON) / charge


def _y_ion(suffix, mod_sum, charge=1):
    """Theoretical C-terminal (y) ion m/z. mod_sum = C-term mod + residue mods on the suffix."""
    neutral = sum(_RESIDUE[a] for a in suffix) + _H2O + mod_sum
    return (neutral + charge * _PROTON) / charge


class TestGenerateIonseries(unittest.TestCase):
    def _frag(self, seq, precursor_charge=2):
        annotations, mz = generate_ionseries(seq, precursor_charge)
        return dict(zip(annotations, mz))

    def test_nterm_mod_keeps_the_proton(self):
        # Regression for the N-terminal modification bug:
        # the unsigned form '.[308.1161]...' made OpenMS read 308.1161 as the
        # *absolute* N-terminal mass and subtract the N-terminal H (1.0078), so
        # b8^1 came out 1158.534038 instead of 1159.5419. The fix writes the
        # delta mass with an explicit '+' sign.
        d = self._frag('.[+308.1161]EVGEHLVSIK[+308.1161]')
        self.assertAlmostEqual(d['b8^1'], _b_ion('EVGEHLVS', 308.1161), delta=0.002)
        self.assertAlmostEqual(d['b8^1'], 1159.5419, delta=0.002)
        # the old, buggy value (proton dropped) must not reappear
        self.assertGreater(abs(d['b8^1'] - 1158.534038), 0.5)

    def test_cterminal_residue_mod(self):
        # The last token of the peptide is a residue mod on K (+308.1161),
        # which is reflected in y1.
        d = self._frag('.[+308.1161]EVGEHLVSIK[+308.1161]')
        self.assertAlmostEqual(d['y1^1'], _y_ion('K', 308.1161), delta=0.002)

    def test_cterm_terminal_mod(self):
        # A true C-terminal modification shifts the y ions and leaves b ions
        # untouched (parallel of the N-term bug on the C-terminus).
        d = self._frag('EVGEHLVSIK.[+100.0]')
        self.assertAlmostEqual(d['y1^1'], _y_ion('K', 100.0), delta=0.002)
        self.assertAlmostEqual(d['b8^1'], _b_ion('EVGEHLVS', 0.0), delta=0.002)

    def test_internal_residue_mod(self):
        # A non-Unimod mass on a specific amino acid (H5) is already correct
        # because that branch emits the signed delta; assert it stays correct.
        d = self._frag('EVGEH[+308.1161]LVSIK')
        self.assertAlmostEqual(d['b5^1'], _b_ion('EVGEH', 308.1161), delta=0.002)
        self.assertAlmostEqual(d['y6^1'], _y_ion('HLVSIK', 308.1161), delta=0.002)
        # ions that do not span the modified residue are unaffected
        self.assertAlmostEqual(d['b4^1'], _b_ion('EVGE', 0.0), delta=0.002)


if __name__ == '__main__':
    unittest.main()
